package com.example.conversormoeda;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView texx;
    TextView texxe;


    private ViewHolder mViewHolder = new ViewHolder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        texx = (TextView) findViewById(R.id.id_C_Dolar);
        texxe = (TextView) findViewById(R.id.id_C_euro);


        new doitE().execute();
        new doit().execute();

        this.mViewHolder.editValue = (EditText) findViewById(R.id.editText);
        this.mViewHolder.textDolar = (TextView) findViewById(R.id.id_text_dolar);
        this.mViewHolder.textEuro = (TextView) findViewById(R.id.id_euro);
        this.mViewHolder.buttonCalcular = (Button) findViewById(R.id.button_calcular);

        this.mViewHolder.buttonCalcular.setOnClickListener(this);

    }


    @Override
    public void onClick(View view) {
        int id = view.getId();

        if (id == R.id.button_calcular) {
            Double valor = Double.valueOf(this.mViewHolder.editValue.getText().toString());
            this.mViewHolder.textDolar.setText(String.format("%.2f", valor * 4.32));
            this.mViewHolder.textEuro.setText(String.format("%.2f", valor * 3.6));

        }
    }

    private static class ViewHolder {
        EditText editValue;
        TextView textDolar;
        TextView textEuro;
        Button buttonCalcular;

    }

    public class doitE extends AsyncTask<Void, Void, Void> {
        String valoreuro;

        @Override
        protected Void doInBackground(Void... voids) {

            try {
                Document doc = Jsoup.connect("https://www.melhorcambio.com/euro-hoje").get();
                Element elementsTagE = doc.getElementById("comercial");

                valoreuro = "1 = " + elementsTagE.toString().substring(26, 30) + " R$";

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVold) {
            super.onPostExecute(aVold);
            texxe.setText(valoreuro);
        }
    }

        public class doit extends AsyncTask<Void, Void, Void> {
            String valordolar;

            @Override
            protected Void doInBackground(Void... voids) {

                try {
                    Document doc = Jsoup.connect("https://dolarhoje.com/").get();
                    Element elementsTag = doc.getElementById("nacional");

                    //tratar o retorno da tag

                    valordolar = "1 = " + elementsTag.toString().substring(40, 44) + " R$";



                } catch (Exception e) {
                    e.printStackTrace();
                }

                return null;
            }

            @Override
            protected void onPostExecute(Void aVold) {
                super.onPostExecute(aVold);
                texx.setText(valordolar);

            }
        }

        public void Share(View v) {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT, "Cambio Hoje");
            intent.putExtra(Intent.EXTRA_TEXT, "Acompanhe as noticias do mercado financeiro\n acesse:https://economia.uol.com.br/cotacoes/");
            startActivity(Intent.createChooser(intent, "choose one"));
        }
    }

